export const environment = {
  production: false,
  apiUrl: '',
  realtimePath: '/ws/payments'
};

