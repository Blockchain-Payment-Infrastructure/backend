export const environment = {
  production: true,
  apiUrl: '',
  realtimePath: '/ws/payments'
};

